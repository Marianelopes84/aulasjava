package RA354112_av_02;

public class RA354112_av_02 {
    public static void main(String[] args) {
        Pessoa pessoa1 = new Pessoa("Mariane", "14/14/1984", 1.53);
        Pessoa pessoa2 = new Pessoa("Britney", "02/02/1991", 1.71);
        Pessoa pessoa3 = new Pessoa("Justin Bieber", "02/04/1995", 1.92);
        
        pessoa1.imprimeDados();
        pessoa2.imprimeDados();
        pessoa3.imprimeDados();
    }
}
